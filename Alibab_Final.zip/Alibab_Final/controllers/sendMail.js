const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'developer3171@gmail.com', // generated ethereal user
    pass: 'tyussjbnqtlexvgv', // generated ethereal password
  }
});


function sendMail(to, subject, text) {
  const mailOptions = {
    from: 'youremail@gmail.com',
    to: to,
    subject: subject,
    text: text
  }
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
    } else {
     // console.log(`Email sent to ${to}: ${info.response}`);
    }
  });
}

module.exports.sendMail=sendMail;