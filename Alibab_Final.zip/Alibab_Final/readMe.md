1) Install NodeJS from official website of nodejs(https://nodejs.org/en/download/)
{skip step one if you already have NodeJS in you system}

2) Open the project folder in command prompt
3) Run cmd : npm install or npm i 
    -> it will install all the dependencies of project
    -> Ignore vulnerabilties
4) Run cmd : npm start
    it will start the server at localhost:3000
5) Open any browser and in the URL bar type localhost:3000
    Now you can acess the Website.

Note: if error comes like port is busy then try to change the port form env file to some other port number like 8080




Refrence email Passwords 
1) For admin -> email: yashsenown3172@gmail.com  Password: yash@456
2) For staff -> email: ramesh24@gmail.com  Password: ramesh@456
3) For Student -> email: shivanshjain@gmail.com Password : shivansh@456